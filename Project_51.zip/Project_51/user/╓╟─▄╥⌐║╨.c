#include <REGX51.H>
//����ҩ��
sbit key1=P1^0;
sbit key2=P1^1;
sbit key3=P1^2;
sbit key4=P1^3;
sbit key5=P1^4;
sbit LED=P1^6;
sbit buzzer=P1^7;

unsigned char i,j,p,m,n,k,w,x,y,z,e;
unsigned char w=0,x=0,y=0,z=0,flag=0,seed=0;
unsigned char str[]={0X3F,0X06,0X5B,0X4F,0X66,0X6D,0X7D,0X07,0X7F,0X6F};

void sign();
void clock();
void set_clock();
void alarm_buz();
void break_off();
void timer(unsigned int t);
void delay(unsigned char a);

void main()
{ 
	TMOD=0X01;                 //0000 0001  ��ʱ��0 ������ʽ1  16λ������
	break_off();               //INT0�ⲿ�ж�0
	while(1)
	{
	 clock();
	}
}

 void break_off()
 {
	 IT0=1;                          //���ش���
	 EX0=1;                          //�ⲿ�ж�0Դ����
	 EA=1;
 }
 
void clock()
{
	for(i=0;i<3;i++)                 //3   ʱʮλ
     {
		 for(k=0;k<10;k++)             //10  ʱ��λ
      {
				if(i>=2&&k>=4)
        {
					j=0;n=0;k=0;i=0;
        }
		   for(n=0;n<6;n++)            //6  ��ʮλ
			  {
	      for(j=0;j<10;j++)          //10 �ָ�λ
		     {					 
	       for(m=0;m<60;m++)         //60 
			    {
		      for(p=0;p<50;p++)        //�ȶ���ʾ    4*5*50=1000
			     {
			      P3=0X8F;               //�ָ�λ
			      P2=~(str[j]+0X80);     //����dp
			      timer(1);
			      P3=0X4F;               //��ʮλ
		        P2=~(str[n]+0X80);
			      timer(1);              
			      P3=0X2F;               //ʱ��λ
			      P2=~(str[k]+0X80);            
			      timer(1);
			      P3=0X1F;               //ʱʮλ
			      P2=~(str[i]+0X80);
			      timer(1);
						set_clock();           //����ʱ��
						sign();                //�������ƹر�
			     }
		      }
					alarm_buz();
		     }
	      }
      }
     }
}

//��������
void sign()
{
	if(key1==0&&flag==0)
	{
		flag=1;
	}
	if(key1==1&&flag==1)
	{
		buzzer=1;
		LED=1;
		flag=0;
	}
}

void timer(unsigned int t)   //��ѯ��ʱ
{
	unsigned char s;
	for(s=0;s<t;s++)           //ѭ����ʱ
	{
		TH0=(65536-5000)/256;    //2��16��=65536
		TL0=(65536-5000)%256;
		TR0=1;                    //����T0
		while(!TF0);              //����Ƿ����
		TF0=0;                    //����
	}
}

 void delay(unsigned char a)
 {
	 unsigned char b,c;
	 for(b=0;b>a;b++)
	 {
		 for(c=0;c<125;c++);
	 }
 }
 
 void alarm_buz()            //�����趨           
 {
	 if((i==0&&k==7&&n==0&&j==4)||(i==1&&k==4&&n==0&&j==4)||(i==1&&k==9&&n==0&&j==4))
	 {
     buzzer=0;
		 LED=0;
	  }else{
		LED=1;
		buzzer=1;
		}
}
 
 void intter() interrupt 0  //�ⲿ�ж�0
 {
	 EX0=0;               	 //�����ֳ�
	 for(e=0;e<=4;)
	 {
	 P0=0XFF<<++e;
	 for(n=0;n<120;n++)      //60s
	 {
   timer(100);             //0.5s
	 }
	 }
	 buzzer=0;
	 for(n=0;n<40;n++)        //20s
	 {
   timer(100);
	 }
	 P0=0XFF;
	 buzzer=1;
	 EX0=1;                   //�ָ��ֳ�
 }
 
 void set_clock()           //ʱ������
 {
//key2�����ָ�λ����
	if(key2==0)
	{
	  delay(10);
		if(key2==0)
		{
		  while(!key2);
			delay(10);
			j++;
		}
	}
		if(j>9)
			{
			 j=0;
			}
//key3������ʮλ����
	 if(key3==0)
	{
	  delay(10);
		if(key3==0)
		{
		  while(!key3);
			delay(10);
			n++;
		}
	}
	 if(n>5)
			{
		   n=0;
			}
//key4����ʱ��λ����
	 if(key4==0)
	{
	  delay(10);
		if(key4==0)
		{
		  while(!key4);
			delay(10);
			k++;
		}
	}
		 if(k>9)
			 {
			 k=0;
			 }
//key5����ʱʮλ����
	if(key5==0)
	{
	  delay(10);
		if(key5==0)
		{
		  while(!key5);
			delay(10);
			i++;
		}
	}
	if(i>2)
	{
	 i=0;
	}
 }
 
 