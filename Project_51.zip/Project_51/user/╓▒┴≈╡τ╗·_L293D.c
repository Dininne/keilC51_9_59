#include <REGX51.H>
//sbit IN1=P0^5;
//sbit IN2=P0^6;
//sbit EN1=P3^1;

//void tomor();
//void stop();
//void obverse();
//void positive();
//void timer(unsigned int t);

//void main()
//{
//	while(1)
//	{
//	tomor();
//	}
//}

////��ʱ��T0
//void timer(unsigned int t)    //��ѯ��ʱ
//{
//	unsigned char s;
//	for(s=0;s<t;s++)            //ѭ����ʱ
//	{
//		TH0=(65536-50000)/256;    //2��16��=65536
//		TL0=(65536-50000)%256;    //50ms
//		TR0=1;                    //����T0
//		while(!TF0);              //����Ƿ����
//		TF0=0;                    //����
//	}
//}
//void tomor()
//{
//	obverse();
//}
//void stop()
//{
//	IN1=0;
//	IN2=0;
//	EN1=1;
//}
//	
//void positive()
//{
//	IN1=1;
//	IN2=0;
////	timer(1);
//	stop();
////	timer(5);
//	EN1=1;
//}
//void obverse()   //���ת��32
//{
//	IN1=0;
//	IN2=1;        //+IN1��ת
////	timer(1);     //50ms     
//	stop();
////	timer(3);
//	EN1=1;
//}
void main()
{
	P1=0XFF;
	P3=0X00;
}
