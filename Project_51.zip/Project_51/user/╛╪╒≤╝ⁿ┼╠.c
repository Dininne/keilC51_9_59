#include <REGX51.H>
//ǰ3������
unsigned char s[]={0X3F,0X06,0X5B,0X4F,0X66,0X6D,0X7D,0X07,0X6F};
unsigned char num=66;    //�����¾Ͳ�����

void delay(unsigned int n);
void display();
void key_scanf();

void main()
{
	while(1)
	{
		key_scanf();
		display();

	}
}
void display()
{
	P2=s[num];
}
void key_scanf()
{
	  unsigned char temp0=0,temp1=0,temp=0;
	  P1=0XF0;
		if(P1!=0XF0)     //��ⰴ���Ƿ񱻰���
		{
			delay(20);
			temp0=P1;
			P1=0X0F;
			if(P1!=0X0F)
			{
				temp1=P1;
			}
		}
		temp=temp0+temp1;
		if(temp==0XEE)
		{
			num=0;
		}
		if(temp==0XED)
		{
			num=1;
		}
		if(temp==0XEB)
		{
			num=2;
		}
}
void delay(unsigned int n)
{
	unsigned int i=0,j=0;
	for(i=0;i<n;i++)
	{
		for(j=0;j<120;j++);
	}
}
