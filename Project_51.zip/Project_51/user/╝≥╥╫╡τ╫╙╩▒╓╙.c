#include <REGX51.H>

sbit RS=P3^0;
sbit RW=P3^1;
sbit E=P3^2;
sbit key1=P1^0;
sbit key2=P1^1;
sbit key3=P3^3;
sbit key4=P1^2;
sbit key5=P1^3;
sbit LED_1=P0^0;
sbit LED_2=P0^1;
sbit LED_3=P0^2;
sbit buzzer=P3^4;

void end();
void buz();
void sign();
void display();
void initlcd();
void set_clock();
void inittemer();
void delay(unsigned char j);
void wrcom(unsigned char k);
void timer_1(unsigned int t);
void wrdata(unsigned char dat);

unsigned char min=0,hour=23,sec,flag=0,amin,ahour,x,y,sign_flag=0;
unsigned char str[]={"0123456789"};

void main()
{
	initlcd();
  inittemer();
	while(1)
	{
		display();
	}
}

void initlcd()          //��ʼ��LCD
{    //DL=1;8λ���ݽӿ�  N=1;������ʾ F=0 5*8�����ַ�
	wrcom(0X38);          //����16*2��ʾ��5*7����,8λ���ݽӿ�
	wrcom(0X0C);          //����D=1 ����ʾ��C=0 ����ʾ��� B=0
	wrcom(0X06);          //����  1/D=1 дһ���ַ��󣬵�ַ+1 S=0 ����ʾ�ƶ�
	wrcom(0X01);          //��ʾ��0������ָ����0
}
void wrcom(unsigned char com)    //д����
{
	RS=0;      //0      RS=0����
	RW=0;      //0      RW=0д    RW=1��
	E=0;
	P2=com;
	delay(10);
	E=1;
	E=0;
}
void wrdata(unsigned char dat)   //д����
{
	RS=1;      //1     RS=1����
	RW=0;      //0     RW=0д
	E=0;
	P2=dat;
	delay(20);
	E=1;
	E=0;
}

void delay(unsigned char j)
{
	unsigned char a,b;
	for(a=0;a<j;a++)
	{
		for(b=0;b<125;b++);
	}
}

void inittemer()
{
	TMOD=0X11;
	TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	ET0=1;
	EA=1;
	TR0=1;
	IT1=1;
	EX1=1;
}

void timer_0() interrupt 1
{
	unsigned char num;
	TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	num++;
	if(num==20)
	{
		sec++;
		num=0;
	}
	if(sec==60)
	{
		min++;
		sec=0;
	}
	if(min==60)
	{
		hour++;
		min=0;
	}
	if(hour==24)
	{
		hour=0;
	}
}

void display()
{
	unsigned char temp0,temp1,temp2,temp3;
  wrcom(0X80+5);                //��ʾλ��
  delay(9);
	if(flag==0)
	{
  temp0=min/10;
  temp1=min%10;
  temp2=hour/10;
  temp3=hour%10;
	}else{
	temp0=amin/10;
  temp1=amin%10;
  temp2=ahour/10;
  temp3=ahour%10;
	}
	buz();
	set_clock();
  wrdata(str[temp2]);
  delay(10);
  wrdata(str[temp3]);
  delay(10);
  wrdata(':');
  delay(10);
  wrdata(str[temp0]);
  delay(10);
  wrdata(str[temp1]);
  delay(10);
	if(flag==1)
	{
	end();
	}
}
void set_clock()
{
	if(key1==0)
	{
		delay(6);
		if(key1==0)
		{
			delay(6);
			while(!key1);
			if(flag==0)
			{
			  min++;
			}else{
				amin++;
			}
		}
	}
	if(key2==0)
	{
		delay(6);
		if(key2==0)
		{
			delay(6);
			while(!key2);
			if(flag==0)
			{
			  hour++;
			}else{
				ahour++;
			}
		}
	}
}
void alarm() interrupt 2
{
	    wrcom(0X01);
			delay(6);
	    flag=1;
	    LED_1=0; 
	    wrcom(0X01);
	    delay(2);
	    display();
	    wrcom(0X01);
	    delay(1);	
}
void end()
{
	if(key4==0)
	{
		delay(6);
		if(key4==0)
		{
			delay(6);
			while(!key4);
			flag=0;
			EX1=0;
			LED_1=1;
			wrcom(0X01);
			EX1=1;
		}
	}
}

void buz()
{
	if(ahour==hour&&amin==min)
	{
		buzzer=0;
		LED_2=0;
		for(x=0;x<60;x++)      //30��
		{
		 timer_1(10);
			sign();
			if(sign_flag!=0)
		  {
			buzzer=1;
	    LED_2=1;	
		  }
		}
		buzzer=1;
	  LED_2=1;		
  if(sign_flag==0)
  {
	 for(y=0;y<240;y++)    //2�ֺ�
	 {
		timer_1(10);	
	 }	
	 buzzer=0;
	 LED_2=0;
	while(key5);
	 buzzer=1;
	 LED_2=1;
  }
 }
}

void timer_1(unsigned int t)   //��ѯ��ʱ
{
	unsigned char s;
	for(s=0;s<t;s++)           //ѭ����ʱ
	{
		TH1=(65536-50000)/256;    //2��16��=65536
		TL1=(65536-50000)%256;
		TR1=1;                    //����T1
		while(!TF1);              //����Ƿ����
		TF1=0;                    //����
	}
}

void sign()
{
	if(key5==0)
	{
		delay(6);
		if(key5==0)
		{
			delay(6);
			while(!key5);
			LED_2=1;
			buzzer=1;
			sign_flag=!sign_flag;
		}
	}
}