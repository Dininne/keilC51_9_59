#include <REGX51.H>

sbit key1=P1^0;

unsigned char code tab[10][8]={
	                              {0X00,0X7E,0XFF,0XC3,0XC3,0XFF,0X7E,0X00},
																{0X00,0X00,0X43,0XFF,0XFF,0X03,0X00,0X00},
																{0X00,0X63,0XC7,0XCF,0XDB,0XF3,0X63,0X00},
																{0X00,0X42,0XDB,0XDB,0XDB,0XFF,0X66,0X00},
																{0X00,0X3E,0X46,0XFF,0XFF,0X06,0X06,0X00},
																{0X00,0XF6,0XF7,0XD3,0XD3,0XDF,0XDE,0X00},
																{0X00,0X7E,0XFF,0XDB,0XDB,0XDF,0X4E,0X00},
																{0X00,0XC0,0XC0,0XC7,0XFF,0XF8,0XC0,0X00},
																{0X00,0XFF,0XFF,0XDB,0XDB,0XFF,0XFF,0X00},
																{0X00,0X72,0XFB,0XDB,0XDB,0XFF,0X7E,0X00},
                               };

unsigned char code row[]={0X01,0X02,0X04,0X08,0X10,0X20,0X40,0X80};

unsigned char s=0,t=0;

void key();
void matrix();
void delay(unsigned int n);
															 
void main()
{
	while(1)
	{
		matrix();
	}
}

void matrix()
{
		for(t=0;t<8;t++)
		{
			P2=~row[t];
			P3=tab[s][t];
			delay(1);
		}
		key();
}

void key()
{
	if(key1==0)
		{
			delay(6);
			if(key1==0)
			{
				delay(6);
				while(!key1);
				s++;
				s=s%10;

			}
		}
}
void delay(unsigned int n)
{
	unsigned char i,j;
	for(i=0;i<n;i++)
	{
		for(j=0;j<125;j++);
	}
}