#include <REGX51.H>

sbit key1=P3^0;
sbit key2=P3^1;
sbit key4=P3^3;
sbit key5=P3^4;
sbit LED_1=P3^5;
sbit LED_2=P3^6;
sbit buzzer=P3^7;

unsigned char code tab[10][4]={
	                             {0X7C,0X82,0X82,0X7C},   //0
	                             {0XC4,0XFE,0XFE,0XC0},   //1
	                             {0XCC,0XA2,0X92,0X8C},   //2
										           {0X54,0X92,0X92,0X6C},   //3
                               {0X38,0X24,0XFE,0X20},   //4
	                             {0X4E,0X8A,0X8A,0X72},   //5
	                             {0X7C,0X92,0X92,0X64},   //6
	                             {0X02,0XE2,0X12,0X0E},   //7
                               {0X6C,0X92,0X92,0X6C},   //8
	                             {0X4C,0X92,0X92,0X7C},   //9
                            };

unsigned char code row[2][4]={
                              {0X01,0X02,0X04,0X08},    //ǰ4
                              {0X10,0X20,0X40,0X80}     //��4
                              };

unsigned char tf,ts,de,hour=0,min=0,sec=0,flag=0,ahour=0,amin=0,asec=0,sign=0;

															
void key();
void end();
void buz();
void mark();
void matrix();
void inittemer();															
void delay(unsigned int n);
void timer_1(unsigned int t);
															 
void main()
{
	inittemer();
	while(1)
	{
		matrix();
		key();
	}
}

void inittemer()                          //��ʱ�����жϳ�ʼ��
{
	TMOD=0X11;
	TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	ET0=1;
	EA=1;
	TR0=1;
	IT0=1;
	EX0=1;
}
void matrix()
{
		for(ts=0;ts<4;ts++)
		{
       P1=row[0][ts];
       if(flag==0)
			 {				 
			  P0=~(tab[hour/10][ts]);
			 }else{
				P0=~(tab[ahour/10][ts]);
			 }
			 delay(1);
			 P1=0X00;		

			 P1=row[1][ts];   
			 if(flag==0)
			 {				 
			  P0=~(tab[hour%10][ts]);
			 }else{
				P0=~(tab[ahour%10][ts]);
			 } 
			 delay(1);
       P1=0X00;
		}
		for(tf=0;tf<4;tf++)
		{
        P2=row[0][tf]; 
       if(flag==0)
			 {				 
			  P1=~(tab[min/10][tf]);
			 }else{
				P1=~(tab[amin/10][tf]);
			 }
			  delay(1);
			  P2=0X00;		

			  P2=row[1][tf];		
			  if(flag==0)
			 {				 
			  P1=~(tab[min%10][tf]);
			 }else{
				 P1=~(tab[amin%10][tf]);
			 }
			  delay(1);
        P2=0X00;
		}
		buz();
		mark();
		if(flag==1)
		{
			end();
		}
}

void key()
{
	if(key1==0)
		{
				delay(6);
			if(key1==0)
			{
				delay(6);
				while(!key1);
				if(flag==0)
				{
				  hour++;
				}else{
					ahour++;
				}
				if(hour>24)
			 {
				hour=0;
			 }else if(ahour>24)
			 {
				 ahour=0;
			 }
			}
		}
		if(key2==0)
		{
				delay(6);
			if(key2==0)
			{
					delay(6);
				while(!key2);
				if(flag==0)
				{
				  min++;
				}else{
					amin++;
				}
				if(min>59)
			 {
				min=0;
				hour++;
			 }else if(amin>59)
			 {
				 amin=0;
				 ahour++;
			 }
			}
		}
}
void delay(unsigned int n)
{
	unsigned char i,j;
	for(i=0;i<n;i++)
	{
		for(j=0;j<125;j++);
	}
}

void timer_2() interrupt 1
{
	unsigned char num;
	TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	num++;
	if(num==20)
	{
		sec++;
		num=0;
	}
	if(sec==60)
	{
		min++;
		sec=0;
	}
	if(min==60)
	{
		hour++;
		min=0;
	}
	if(hour==24)
	{
		hour=0;
	}
}

void timer_1(unsigned int t)   //��ѯ��ʱ
{
	unsigned char s;
	for(s=0;s<t;s++)           //ѭ����ʱ
	{
		TH1=(65536-50000)/256;    //2��16��=65536
		TL1=(65536-50000)%256;
		TR1=1;                    //����T1
		while(!TF1);              //����Ƿ����
		TF1=0;                    //����
	}
}

void alarm() interrupt 0
{
	sign=1;
	flag=!flag;
	if(flag==1)
	{
	LED_1=0;
	matrix();
	}
}

void end()
{
	if(key4==0)
	{
		delay(6);
		if(key4==0)
		{
			delay(6);
			while(!key4);
			flag=0;
			LED_1=1;
			EX0=0;
			EX0=1;
		}
	}
}

void buz()
{
	if(sign==1)
	{
	 if(ahour==hour&&amin==min)
	 {
	  buzzer=0;
		 mark();
	 }
  }
}

void mark()
{
	if(key5==0)
	{
		delay(6);
		if(key5==0)
		{
			delay(6);
			while(!key5);
			buzzer=1;
			sign=0;
		}
	}
}