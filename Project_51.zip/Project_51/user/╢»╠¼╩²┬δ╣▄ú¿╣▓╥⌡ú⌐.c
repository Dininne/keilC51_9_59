#include <REGX51.H>

unsigned char str[]={0X76,0X79,0X38,0X38,0X3F};  //hello

unsigned char wei[]={0X01,0X02,0X04,0X08,0X10};  //λ����

void delay(unsigned int n)
{
	int i,j;
	for(i=0;i<n;i++)
	{
		for(j=0;j<120;j++);
	}
}
void main()
{
	int i=0;
	while(1)
	{
		for(i=0;i<=4;i++)   //ѭ����ʾ
		{	
			
			P3=~wei[i];
			
		  P2=str[i];        //������ʾ
			
		  delay(666);       //��ʱ����
			
		}
	}
}