#include <REGX51.H>

unsigned int temp;
unsigned int code LED[]={0XFF,0XFE,0XFC,0XF8,0XF0,0XE0,0XC0,0X80,0X00};
void timer(unsigned int i);

void main()
{
	TMOD=0X01;                       //��ʱ��0��������ʽ1
  while(1)
 {
    for(temp=0;temp<=8;temp++)      //
	 {
		P2=LED[temp];
		timer(20);
	 }
 }
}
void timer(unsigned int i)
{
  unsigned int j;
	for(j=0;j<i;j++)
	{
	  TH0=(65536-50000)/256;
		TL0=(65536-50000)%256;
		TR0=1;
		while(TF0==0);
		TF0=0;
	}
}