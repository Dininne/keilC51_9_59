#include <REGX51.H>
unsigned int code num[10]={0XC0,0XF9,0XA4,0XB0,0X99,0X92,0X82,0XF8,0X80,0X90};   //����0-9
sbit key0=P1^0;
int flag=0;
unsigned int i=0;
void key()                      //��������
{
    if(key0==0&&flag==0)
		{
		   flag=1;
		}
		if(key0==1&&flag==1)
		{
		     i++;
			flag=0;
		}
}
void seg()                       //ѭ�������0-9
{
   P2=num[i];
	 if(i==10)                     //����ѭ��
	 {
	    i=0;
	 }
}
void main()                      
{
    while(1)
		{
		  key();
		  seg();
		}
}
	
	
	
	
	
