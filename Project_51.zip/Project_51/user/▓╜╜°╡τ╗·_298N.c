#include <REGX51.H>

unsigned char str[]={0X09,0X08,0X0C,0X04,0X06,0X02,0X03,0X01};

void positive();
void obverse();
void stepper();
void timer(unsigned int t);

void main()
{
	while(1)
	{
		stepper();
	}
}

//��ʱ��T0
void timer(unsigned int t)   //��ѯ��ʱ
{
	unsigned char s;
	for(s=0;s<t;s++)           //ѭ����ʱ
	{
		TH0=(65536-50000)/256;    //2��16��=65536
		TL0=(65536-50000)%256;     //50ms
		TR0=1;                    //����T0
		while(!TF0);              //����Ƿ����
		TF0=0;                    //����
	}
}
void stepper()
{
	obverse();
//	positive();
}
void positive()    //��ת
{
	unsigned char i;
	for(i=0;i<8;i++)
	{
		P2=str[i];
		timer(100);
	}
}
void obverse()      //��ת
{
	unsigned char j;
	for(j=7;j>0;j--)
	{
		P2=str[j];
		timer(100);
	}
}
